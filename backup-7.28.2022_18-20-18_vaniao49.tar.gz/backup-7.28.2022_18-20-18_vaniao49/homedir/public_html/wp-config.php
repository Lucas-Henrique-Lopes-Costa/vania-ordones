<?php

//Begin Really Simple SSL session cookie settings
@ini_set('session.cookie_httponly', true);
@ini_set('session.cookie_secure', true);
@ini_set('session.use_only_cookies', true);
//END Really Simple SSL
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'vaniao49_wp583' );

/** MySQL database username */
define( 'DB_USER', 'vaniao49_wp583' );

/** MySQL database password */
define( 'DB_PASSWORD', '4B8-1pm]Sb' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'tf9zgdguwmoeplknu5sqwieb97jxxyzkx3ufwrjy8bb3mroj4kgyqkx01vlvnxoa' );
define( 'SECURE_AUTH_KEY',  '6t6dbfur7l6de2xwrzopgcipek3i6nxmekcdsnziqjhzayuyalfjhipqnuzxnxkg' );
define( 'LOGGED_IN_KEY',    'hjxfzwvj0jn8mowwyhsltlsshxctje9tenpir378gysmonlk21m2w5j7y1ssicha' );
define( 'NONCE_KEY',        'rwmiwjhv4tox6bsq9xjpea0p0xlujnxkl6arhmfsiefovujnab2lg32tbtbdpohz' );
define( 'AUTH_SALT',        '6hihhv2iha4m8qedplvkfjlhzkbwz1oxsd2z1gu9xdw8it8aeotod6w9f7pgkvbl' );
define( 'SECURE_AUTH_SALT', 'w45szpkwevcx9ey6miuuvxzgzhzqbhfso68jt4yzs0bvvkyv7sspfy92fbfpz6jn' );
define( 'LOGGED_IN_SALT',   'myi5cku22u65o3cr3cdwckiscr3zjno5labqnwiz3ftgcchc7tglsudpwp0llpdy' );
define( 'NONCE_SALT',       'tqmagpmuvlv04s2idi0mhcmtko9ap26gbcmdm8q5rvnmoxgbpmc1moamc7dakvm7' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp8r_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
